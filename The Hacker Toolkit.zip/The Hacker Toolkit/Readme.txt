>> DONOT run the MaldevScr.cmd first. DONOT means DONOT !!!

1. Use the name 'MaldevScr.cmd' for the name of the script in option 3
2. You can use any name or any server for the Brute Force option
3. You can use any server IP for the option 3
4. Define the port 'eth0' as the port for the option 4
5. That's it and enjoy !!


// These scripts are not harmful to your pc or any others by anymeans
// The only purpose was to create this is to have fun with your and your friends as well as the educational purpose
// You can change the echo sections as your want but do not change the values cuz it may lead to not to work this as expected...
// Thank you for using my script <3
// Created and Developed by Manu